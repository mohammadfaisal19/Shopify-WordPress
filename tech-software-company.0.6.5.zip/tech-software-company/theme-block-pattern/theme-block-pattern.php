<?php
/**
 * Tech Software Company: Block Patterns
 *
 * @package  Tech Software Company
 * @since   1.0.0
 */

/**
 * Register Block Pattern Category.
 */
if ( function_exists( 'register_block_pattern_category' ) ) {

	register_block_pattern_category(
		'tech-software-company',
		array( 'label' => __( ' Tech Software Company', 'tech-software-company' ) )
	);
}

/**
 * Register Block Patterns.
 */

if ( function_exists( 'register_block_pattern' ) ) {
	register_block_pattern(
		'tech-software-company/banner-section',
		array(
			'title'      => __( 'Banner Section', 'tech-software-company' ),
			'categories' => array( 'tech-software-company' ),
			'content'    => "<!-- wp:cover {\"url\":\"" . esc_url(get_template_directory_uri()) . "/theme-block-pattern/images/banner.png\",\"id\":60,\"dimRatio\":50,\"customOverlayColor\":\"#01014e\",\"isUserOverlayColor\":true,\"isDark\":false,\"align\":\"full\",\"className\":\"banner-section \"} -->\n<div class=\"wp-block-cover alignfull is-light banner-section\"><span aria-hidden=\"true\" class=\"wp-block-cover__background has-background-dim\" style=\"background-color:#01014e\"></span><img class=\"wp-block-cover__image-background wp-image-60\" alt=\"\" src=\"" . esc_url(get_template_directory_uri()) . "/theme-block-pattern/images/banner.png\" data-object-fit=\"cover\"/><div class=\"wp-block-cover__inner-container\"><!-- wp:columns -->\n<div class=\"wp-block-columns\"><!-- wp:column {\"width\":\"6.4%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:6.4%\"></div>\n<!-- /wp:column -->\n\n<!-- wp:column {\"width\":\"50%\",\"className\":\"banner-section-content mx-md-3  \"} -->\n<div class=\"wp-block-column banner-section-content mx-md-3\" style=\"flex-basis:50%\"><!-- wp:paragraph {\"style\":{\"elements\":{\"link\":{\"color\":{\"text\":\"var:preset|color|white\"}}},\"typography\":{\"fontSize\":\"16px\",\"textTransform\":\"capitalize\"}},\"textColor\":\"white\"} -->\n<p class=\"has-white-color has-text-color has-link-color\" style=\"font-size:16px;text-transform:capitalize\">software development</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading {\"level\":1,\"style\":{\"typography\":{\"fontSize\":\"45px\"}},\"textColor\":\"white\"} -->\n<h1 class=\"wp-block-heading has-white-color has-text-color\" style=\"font-size:45px\">Offering Smart IT Software Solutions</h1>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph {\"style\":{\"typography\":{\"fontSize\":\"18px\"}},\"textColor\":\"white\",\"className\":\"pt-2 pb-5\"} -->\n<p class=\"pt-2 pb-5 has-white-color has-text-color\" style=\"font-size:18px\">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:buttons -->\n<div class=\"wp-block-buttons\"><!-- wp:button {\"backgroundColor\":\"white\",\"style\":{\"color\":{\"text\":\"#fe5970\"},\"typography\":{\"fontSize\":\"16px\"},\"border\":{\"radius\":\"5px\"}},\"className\":\"banner-section-btn\"} -->\n<div class=\"wp-block-button has-custom-font-size banner-section-btn\" style=\"font-size:16px\"><a class=\"wp-block-button__link has-white-background-color has-text-color has-background wp-element-button\" style=\"border-radius:5px;color:#fe5970\">Contact Us</a></div>\n<!-- /wp:button --></div>\n<!-- /wp:buttons --></div>\n<!-- /wp:column -->\n\n<!-- wp:column {\"width\":\"25%\"} -->\n<div class=\"wp-block-column\" style=\"flex-basis:25%\"></div>\n<!-- /wp:column --></div>\n<!-- /wp:columns --></div></div>\n<!-- /wp:cover -->",
		)
	);
}