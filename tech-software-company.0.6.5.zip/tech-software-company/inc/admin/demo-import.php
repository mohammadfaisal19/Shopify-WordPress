<div class="demo-content">
	<?php 
    // Check if the demo import has been completed
    $tech_software_company_demo_import_completed = get_option('tech_software_company_demo_import_completed', false);

    // If the demo import is completed, display the "View Site" button
    if ($tech_software_company_demo_import_completed) {
      echo '<p class="notice-text">' . esc_html__('Your demo import has been completed successfully.', 'tech-software-company') . '</p>';
      echo '<a href="' . esc_url(home_url()) . '" class="view-btn" target="_blank">' . esc_html__('VIEW SITE', 'tech-software-company') . '</a>';
    }

    if (isset($_POST['submit'])) {

    // Check if Contact Form 7 is installed and activated
    if (!is_plugin_active('contact-form-7/wp-contact-form-7.php')) {
      // Install the plugin if it doesn't exist
      $tech_software_company_plugin_slug = 'contact-form-7';
      $tech_software_company_plugin_file = 'contact-form-7/wp-contact-form-7.php';

      // Check if plugin is installed
      $tech_software_company_installed_plugins = get_plugins();
      if (!isset($tech_software_company_installed_plugins[$tech_software_company_plugin_file])) {
          include_once(ABSPATH . 'wp-admin/includes/plugin-install.php');
          include_once(ABSPATH . 'wp-admin/includes/file.php');
          include_once(ABSPATH . 'wp-admin/includes/misc.php');
          include_once(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php');

          // Install the plugin
          $tech_software_company_upgrader = new Plugin_Upgrader();
          $tech_software_company_upgrader->install('https://downloads.wordpress.org/plugin/contact-form-7.latest-stable.zip');
      }
      // Activate the plugin
      activate_plugin($tech_software_company_plugin_file);
    }

    // --- Menu ---
    $tech_software_company_primary_menu_name = 'Main Menu';
    $tech_software_company_primary_menu_location = 'primary';
    $tech_software_company_primary_menu_exists = wp_get_nav_menu_object($tech_software_company_primary_menu_name);

    if (!$tech_software_company_primary_menu_exists) {
        // Create the left menu
        $tech_software_company_primary_menu_id = wp_create_nav_menu($tech_software_company_primary_menu_name);

        // Create and assign the Home page
        $tech_software_company_home_page_id = wp_insert_post(array(
            'post_type'     => 'page',
            'post_title'    => 'Home',
            'post_content'  => '',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_name'     => 'home'
        ));
        // Assign template and set as front page
        add_post_meta($tech_software_company_home_page_id, '_wp_page_template', 'page-template/custom-front-page.php');
        update_option('page_on_front', $tech_software_company_home_page_id);
        update_option('show_on_front', 'page');

        // Add Home page to the left menu
        wp_update_nav_menu_item($tech_software_company_primary_menu_id, 0, array(
            'menu-item-title'     => __('Home', 'tech-software-company'),
            'menu-item-classes'   => 'home',
            'menu-item-url'       => home_url('/'),
            'menu-item-status'    => 'publish',
            'menu-item-object-id' => $tech_software_company_home_page_id,
            'menu-item-object'    => 'page',
            'menu-item-type'      => 'post_type',
        ));

        // Create and assign the About Us page
        $tech_software_company_about_us_page_id = wp_insert_post(array(
            'post_type'     => 'page',
            'post_title'    => 'About Us',
            'post_content'  => 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which dont look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isnt anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.',
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_name'     => 'about-us'
        ));

        // Add About Us page to the left menu
        wp_update_nav_menu_item($tech_software_company_primary_menu_id, 0, array(
            'menu-item-title'     => __('About Us', 'tech-software-company'),
            'menu-item-classes'   => 'about-us',
            'menu-item-url'       => home_url('/about-us/'),
            'menu-item-status'    => 'publish',
            'menu-item-object-id' => $tech_software_company_about_us_page_id,
            'menu-item-object'    => 'page',
            'menu-item-type'      => 'post_type',
        ));

        // Assign left menu to its location
        $tech_software_company_locations = get_theme_mod('nav_menu_locations', array());
        $tech_software_company_locations[$tech_software_company_primary_menu_location] = $tech_software_company_primary_menu_id;
        set_theme_mod('nav_menu_locations', $tech_software_company_locations);
    }  

    // Set the demo import completion flag
    update_option('tech_software_company_demo_import_completed', true);

    // Display success message and "View Site" button
    echo '<p class="notice-text">' . esc_html__('Your demo import has been completed successfully.', 'tech-software-company') . '</p>';
    echo '<span><a href="' . esc_url(home_url()) . '" class="view-btn" target="_blank">' . esc_html__('VIEW SITE', 'tech-software-company') . '</a></span>';

    //end

    // Topbar Section
    set_theme_mod( 'tech_software_company_topbar_text', '!!Welcome to our IT Software Company Theme' );
    set_theme_mod( 'tech_software_company_mail1', 'support@example.com' );
    set_theme_mod( 'tech_software_company_phone1', '411 6700 123 +62' );
    set_theme_mod( 'tech_software_company_loction1', '99S.T. JOMBLO PARK' );

    // Social Icons Section
    set_theme_mod( 'tech_software_company_facebook_url', '#' );
    set_theme_mod( 'tech_software_company_twitter_url', '#' );
    set_theme_mod( 'tech_software_company_linkedin_url', '#' );
    set_theme_mod( 'tech_software_company_instagram_url', '#' );

    set_theme_mod( 'tech_software_company_slider_small_title', 'Software Development' );
    // Slider
    for($tech_software_company_i=1;$tech_software_company_i<=4;$tech_software_company_i++){
       $tech_software_company_slider_title = 'Offering Smart IT Software Solutions';
       $tech_software_company_slider_content = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua Ut enim ad minim.';
          // Create post object
       $tech_software_company_my_post = array(
       'post_title'    => wp_strip_all_tags( $tech_software_company_slider_title ),
       'post_content'  => $tech_software_company_slider_content,
       'post_status'   => 'publish',
       'post_type'     => 'page',
       );

       // Insert the post into the database
       $tech_software_company_post_id = wp_insert_post( $tech_software_company_my_post );

       if ($tech_software_company_post_id) {
         // Set the theme mod for the slider page
         set_theme_mod('tech_software_company_slider_page' . $tech_software_company_i, $tech_software_company_post_id);

          $tech_software_company_image_url = get_template_directory_uri().'/images/slider'.$tech_software_company_i.'.png';

        $tech_software_company_image_id = media_sideload_image($tech_software_company_image_url, $tech_software_company_post_id, null, 'id');

            if (!is_wp_error($tech_software_company_image_id)) {
                // Set the downloaded image as the post's featured image
                set_post_thumbnail($tech_software_company_post_id, $tech_software_company_image_id);
            }
        }
    }

    // contact form shortcode
    $tech_software_company_cf7title = "Contact Page";
    $tech_software_company_cf7content = '
    <label> Your name
        [text* your-name autocomplete:name] </label>

    <label> Your email
        [email* your-email autocomplete:email] </label>

    <label> Subject
        [text* your-subject] </label>

    <label> Your message (optional)
        [textarea your-message] </label>

    [submit "Submit"]


    [_site_title] "[your-subject]"
    [_site_title] <support@example.com>
    From: [your-name] <[your-email]>
    Subject: [your-subject]

    Message Body:
    [your-message]

    --
    This e-mail was sent from a contact form on [_site_title] ([_site_url])
    [_site_admin_email]
    Reply-To: [your-email]

    0
    0

    [_site_title] "[your-subject]"
    [_site_title] <support@example.com>
    Message Body:
    [your-message]

    --
    This e-mail was sent from a contact form on [_site_title] ([_site_url])
    [your-email]
    Reply-To: [_site_admin_email]

    0
    0
    Thank you for your message. It has been sent.
    There was an error trying to send your message. Please try again later.
    One or more fields have an error. Please check and try again.
    There was an error trying to send your message. Please try again later.
    You must accept the terms and conditions before sending your message.
    The field is required.
    The field is too long.
    The field is too short.
    There was an unknown error uploading the file.
    You are not allowed to upload files of this type.
    The file is too big.
    There was an error uploading the file.';

    $tech_software_company_cf7_post = array(
    'post_title'    => wp_strip_all_tags( $tech_software_company_cf7title ),
    'post_content'  => $tech_software_company_cf7content,
    'post_status'   => 'publish',
    'post_type'     => 'wpcf7_contact_form',
    );
    // Insert the post into the database
    $tech_software_company_cf7post_id = wp_insert_post( $tech_software_company_cf7_post );

    add_post_meta($tech_software_company_cf7post_id, "_form", '
    <label> Your name
        [text* your-name autocomplete:name] </label>

    <label> Your email
        [email* your-email autocomplete:email] </label>

    <label> Subject
        [text* your-subject] </label>

    <label> Your message (optional)
        [textarea your-message] </label>

    [submit "Submit"]
    ');

    $tech_software_company_cf7mail_data  = array('subject' => '[_site_title] "[your-subject]"',
        'sender' => '[_site_title] <support@example.com>',
        'body' => 'From: [your-name] <[your-email]>
    Subject: [your-subject]

    Message Body:
    [your-message]

    --
    This e-mail was sent from a contact form on [_site_title] ([_site_url])',
        'recipient' => '[_site_admin_email]',
        'additional_headers' => 'Reply-To: [your-email]',
        'attachments' => '',
        'use_html' => 0,
        'exclude_blank' => 0 );

    add_post_meta($tech_software_company_cf7post_id, "_mail", $tech_software_company_cf7mail_data);
              // Gets term object from Tree in the database.
    $tech_software_company_cf7shortcode = '[contact-form-7 id="'.$tech_software_company_cf7post_id.'" title="'.$tech_software_company_cf7title.'"]';
    set_theme_mod( 'tech_software_company_slider_contact_form',$tech_software_company_cf7shortcode ); 
    }
    ?>

	<p><strong><?php esc_html_e('Reminder : ', 'tech-software-company'); ?></strong><?php esc_html_e('Backup your site before importing. This process will overwrite existing Tech Software Company settings.', 'tech-software-company'); ?></p>

    <form action="<?php echo esc_url(home_url()); ?>/wp-admin/themes.php?page=tech_software_company_guide" method="POST" onsubmit="return validate(this);">
    <?php if (!get_option('tech_software_company_demo_import_completed')) : ?>
        <form method="post">
            <input class= "run-import" type="submit" name="submit" value="<?php esc_attr_e('Run Importer','tech-software-company'); ?>" class="button button-primary button-large">
        </form>
    <?php endif; ?>
    </form>
	<script type="text/javascript">
		function validate(valid) {
			 if(confirm("Do you really want to import the theme demo content?")){
			    document.forms[0].submit();
			}
		    else {
			    return false;
		    }
		}
	</script>
</div>
