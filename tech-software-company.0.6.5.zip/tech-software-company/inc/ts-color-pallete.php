<?php

	/*---------------------------First Theme color option-------------------*/
	$tech_software_company_theme_color_first = get_theme_mod('tech_software_company_theme_color_first');

	$tech_software_company_custom_css = '';

	$tech_software_company_custom_css .='input[type="submit"], .read-moresec a, .top-header,.main-menu, .primary-navigation ul ul a, .page-template-custom-front-page .main-menu-bg, #slider, .read-more-btn a:hover, .tags p a:hover, .meta-nav:hover, #footer, #footer .tagcloud a:hover, #comments a.comment-reply-link, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce .widget_price_filter .ui-slider .ui-slider-range,.woocommerce .widget_price_filter .ui-slider .ui-slider-handle, #footer form.woocommerce-product-search button, #footer .woocommerce a.button,#footer .widget_price_filter .price_slider_amount .button, .copyright, .wp-block-woocommerce-cart .wc-block-components-totals-coupon a:hover, .wp-block-woocommerce-cart .wc-block-cart__submit-container a:hover, .wp-block-woocommerce-checkout .wc-block-components-totals-coupon a:hover, .wp-block-woocommerce-checkout .wc-block-checkout__actions_row a:hover, .bradcrumbs a:hover, .post-categories li a:hover{';
		$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_theme_color_first).';';
	$tech_software_company_custom_css .='}';

	$tech_software_company_custom_css .='h1,h2,h3,h4,h5,h6,a, .entry-content p a , .comment p a, .woocommerce-product-details__short-description p a, .entry-content ul li a, .entry-content ol li a, .entry-content code, .logo a, .new-text h2 a, .metabox a:hover, .tags i, .tags p a, .meta-nav, .post-title, #sidebar table#wp-calendar td a, #comments a time, h2.woocommerce-loop-product__title, .woocommerce ul.products li.product .price,.woocommerce div.product p.price, .woocommerce div.product span.price, .woocommerce .quantity .qty, .woocommerce-info::before, #sidebar caption, #sidebar h3, #sidebar .textwidget a, #sidebar ul li a:hover, #sidebar ul li a:active, #sidebar ul li a:focus, #sidebar h3, #sidebar .widget_block h2{';
		$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_theme_color_first).';';
	$tech_software_company_custom_css .='}';

	$tech_software_company_custom_css .='.page-box, .tags p a, .woocommerce .quantity .qty, #sidebar form.woocommerce-product-search button, #sidebar aside{';
		$tech_software_company_custom_css .='border-color: '.esc_attr($tech_software_company_theme_color_first).';';
	$tech_software_company_custom_css .='}';

	$tech_software_company_custom_css .='.woocommerce-info{';
		$tech_software_company_custom_css .='border-top-color: '.esc_attr($tech_software_company_theme_color_first).';';
	$tech_software_company_custom_css .='}';

/*---------------------------Second Theme color option-------------------*/
	$tech_software_company_theme_color_second = get_theme_mod('tech_software_company_theme_color_second');

	$tech_software_company_custom_css .='.innerlightbox input[type="submit"], .read-moresec a:hover, #slider .carousel-caption .read-btn a:hover, .read-more-btn a, .woocommerce nav.woocommerce-pagination ul li a:focus, .woocommerce nav.woocommerce-pagination ul li a:hover, .woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce span.onsale, .woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button,.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, #sidebar form.woocommerce-product-search button, #sidebar input[type="submit"], #sidebar .tagcloud a:hover, .pagination a:hover, .pagination .current, .post-categories li a, .toggle-menu i, #sidebar #block-2 button[type="submit"], .page-links .post-page-numbers.current, .page-links a:hover, #sidebar .widget_block.widget_tag_cloud a:hover, .page-box-single .wp-block-tag-cloud a:hover, .wp-block-woocommerce-cart .wc-block-components-totals-coupon a, .wp-block-woocommerce-cart .wc-block-cart__submit-container a, .wp-block-woocommerce-checkout .wc-block-components-totals-coupon a, .wp-block-woocommerce-checkout .wc-block-checkout__actions_row a{';
		$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_theme_color_second).';';
	$tech_software_company_custom_css .='}';

	$tech_software_company_custom_css .='p.logged-in-as a, .info-header i, .primary-navigation li a:hover, .primary-navigation a:focus, #slider .carousel-caption .read-btn a, .slider-nex-pre i, .page-box .metabox,.page-box-single .metabox,.metabox a, a.showcoupon,.woocommerce-message::before, h2.entry-title,h1.page-title{';
		$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_theme_color_second).';';
	$tech_software_company_custom_css .='}';

	$tech_software_company_custom_css .='#comments input[type="submit"].submit, nav.woocommerce-MyAccount-navigation ul li, #sidebar ul li:hover:before, .bradcrumbs a, .bradcrumbs span{';
		$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_theme_color_second).'!important;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_custom_css .='.logo p{';
		$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_theme_color_second).'!important;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_custom_css .='.related-box{';
		$tech_software_company_custom_css .='border-color: '.esc_attr($tech_software_company_theme_color_second).';';
	$tech_software_company_custom_css .='}';

	$tech_software_company_custom_css .='.woocommerce-message{';
		$tech_software_company_custom_css .='border-top-color: '.esc_attr($tech_software_company_theme_color_second).';';
	$tech_software_company_custom_css .='}';

	/*---------------------------Width Layout -------------------*/
	$tech_software_company_theme_lay = get_theme_mod( 'tech_software_company_theme_options','Default');
    if($tech_software_company_theme_lay == 'Default'){
		$tech_software_company_custom_css .='body{';
			$tech_software_company_custom_css .='max-width: 100%;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_theme_lay == 'Container'){
		$tech_software_company_custom_css .='body{';
			$tech_software_company_custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$tech_software_company_custom_css .='}';
		$tech_software_company_custom_css .='.serach_outer{';
			$tech_software_company_custom_css .='width: 97.7%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_theme_lay == 'Box Container'){
		$tech_software_company_custom_css .='body{';
			$tech_software_company_custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$tech_software_company_custom_css .='}';
		$tech_software_company_custom_css .='.serach_outer{';
			$tech_software_company_custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto; right:0';
		$tech_software_company_custom_css .='}';
		$tech_software_company_custom_css .='.page-template-custom-front-page #header{';
			$tech_software_company_custom_css .='right:0;';
		$tech_software_company_custom_css .='}';
	}

	/*---------------------------Slider Content Layout -------------------*/
	$tech_software_company_theme_lay = get_theme_mod( 'tech_software_company_slider_content_alignment','Left');
    if($tech_software_company_theme_lay == 'Left'){
		$tech_software_company_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1, #slider .inner_carousel p, #slider .readbutton{';
			$tech_software_company_custom_css .='text-align:left;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_theme_lay == 'Center'){
		$tech_software_company_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1, #slider .inner_carousel p, #slider .readbutton{';
			$tech_software_company_custom_css .='text-align:center !important;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_theme_lay == 'Right'){
		$tech_software_company_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1, #slider .inner_carousel p, #slider .readbutton{';
			$tech_software_company_custom_css .='text-align:right !important;';
		$tech_software_company_custom_css .='}';
	}

	/*--------------------------- Slider Opacity -------------------*/
	$tech_software_company_theme_lay = get_theme_mod( 'tech_software_company_slider_image_opacity','0.5');
	if($tech_software_company_theme_lay == '0'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0';
		$tech_software_company_custom_css .='}';
		}else if($tech_software_company_theme_lay == '0.1'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0.1';
		$tech_software_company_custom_css .='}';
		}else if($tech_software_company_theme_lay == '0.2'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0.2';
		$tech_software_company_custom_css .='}';
		}else if($tech_software_company_theme_lay == '0.3'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0.3';
		$tech_software_company_custom_css .='}';
		}else if($tech_software_company_theme_lay == '0.4'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0.4';
		$tech_software_company_custom_css .='}';
		}else if($tech_software_company_theme_lay == '0.5'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0.5';
		$tech_software_company_custom_css .='}';
		}else if($tech_software_company_theme_lay == '0.6'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0.6';
		$tech_software_company_custom_css .='}';
		}else if($tech_software_company_theme_lay == '0.7'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0.7';
		$tech_software_company_custom_css .='}';
		}else if($tech_software_company_theme_lay == '0.8'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0.8';
		$tech_software_company_custom_css .='}';
		}else if($tech_software_company_theme_lay == '0.9'){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:0.9';
		$tech_software_company_custom_css .='}';
		}

	/*------------- Button Settings option-------------------*/
	$tech_software_company_button_padding_top_bottom = get_theme_mod('tech_software_company_button_padding_top_bottom');
	$tech_software_company_button_padding_left_right = get_theme_mod('tech_software_company_button_padding_left_right');
	$tech_software_company_custom_css .='.new-text .read-more-btn a, #slider .inner_carousel .read-btn a, #comments .form-submit input[type="submit"],#category .explore-btn a{';
		$tech_software_company_custom_css .='padding-top: '.esc_attr($tech_software_company_button_padding_top_bottom).'px !important; padding-bottom: '.esc_attr($tech_software_company_button_padding_top_bottom).'px !important; padding-left: '.esc_attr($tech_software_company_button_padding_left_right).'px !important; padding-right: '.esc_attr($tech_software_company_button_padding_left_right).'px !important; display:inline-block;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_button_border_radius = get_theme_mod('tech_software_company_button_border_radius');
	$tech_software_company_custom_css .='.new-text .read-more-btn a, #slider .inner_carousel .read-btn a, #comments .form-submit input[type="submit"], #category .explore-btn a{';
		$tech_software_company_custom_css .='border-radius: '.esc_attr($tech_software_company_button_border_radius).'px;';
	$tech_software_company_custom_css .='}';

	/*------------------ Skin Option  -------------------*/
	$tech_software_company_theme_lay = get_theme_mod( 'tech_software_company_background_skin_mode','Transparent Background');
    if($tech_software_company_theme_lay == 'With Background'){
		$tech_software_company_custom_css .='.page-box, #sidebar .widget,.woocommerce ul.products li.product, .woocommerce-page ul.products li.product,.front-page-content,.background-img-skin, .noresult-content{';
			$tech_software_company_custom_css .='background-color: #fff;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_theme_lay == 'Transparent Background'){
		$tech_software_company_custom_css .='.page-box-single{';
			$tech_software_company_custom_css .='background-color: transparent;';
		$tech_software_company_custom_css .='}';
	}

	/*------------ Woocommerce Settings  --------------*/
	$tech_software_company_top_bottom_product_button_padding = get_theme_mod('tech_software_company_top_bottom_product_button_padding', 10);
	$tech_software_company_custom_css .='.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce button.button:disabled, .woocommerce button.button:disabled[disabled]{';
		$tech_software_company_custom_css .='padding-top: '.esc_attr($tech_software_company_top_bottom_product_button_padding).'px; padding-bottom: '.esc_attr($tech_software_company_top_bottom_product_button_padding).'px;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_left_right_product_button_padding = get_theme_mod('tech_software_company_left_right_product_button_padding', 16);
	$tech_software_company_custom_css .='.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce button.button:disabled, .woocommerce button.button:disabled[disabled]{';
		$tech_software_company_custom_css .='padding-left: '.esc_attr($tech_software_company_left_right_product_button_padding).'px; padding-right: '.esc_attr($tech_software_company_left_right_product_button_padding).'px;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_product_button_border_radius = get_theme_mod('tech_software_company_product_button_border_radius', 0);
	$tech_software_company_custom_css .='.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce button.button:disabled, .woocommerce button.button:disabled[disabled]{';
		$tech_software_company_custom_css .='border-radius: '.esc_attr($tech_software_company_product_button_border_radius).'px;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_show_related_products = get_theme_mod('tech_software_company_show_related_products',true);
	if($tech_software_company_show_related_products == false){
		$tech_software_company_custom_css .='.related.products{';
			$tech_software_company_custom_css .='display: none;';
		$tech_software_company_custom_css .='}';
	}

	$tech_software_company_show_wooproducts_border = get_theme_mod('tech_software_company_show_wooproducts_border', false);
	if($tech_software_company_show_wooproducts_border == true){
		$tech_software_company_custom_css .='.products li{';
			$tech_software_company_custom_css .='border: 1px solid #767676;';
		$tech_software_company_custom_css .='}';
	}

	$tech_software_company_top_bottom_wooproducts_padding = get_theme_mod('tech_software_company_top_bottom_wooproducts_padding',0);
	$tech_software_company_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
		$tech_software_company_custom_css .='padding-top: '.esc_attr($tech_software_company_top_bottom_wooproducts_padding).'px !important; padding-bottom: '.esc_attr($tech_software_company_top_bottom_wooproducts_padding).'px !important;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_left_right_wooproducts_padding = get_theme_mod('tech_software_company_left_right_wooproducts_padding',0);
	$tech_software_company_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
		$tech_software_company_custom_css .='padding-left: '.esc_attr($tech_software_company_left_right_wooproducts_padding).'px !important; padding-right: '.esc_attr($tech_software_company_left_right_wooproducts_padding).'px !important;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_wooproducts_border_radius = get_theme_mod('tech_software_company_wooproducts_border_radius',0);
	$tech_software_company_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
		$tech_software_company_custom_css .='border-radius: '.esc_attr($tech_software_company_wooproducts_border_radius).'px;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_wooproducts_box_shadow = get_theme_mod('tech_software_company_wooproducts_box_shadow',0);
	$tech_software_company_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
		$tech_software_company_custom_css .='box-shadow: '.esc_attr($tech_software_company_wooproducts_box_shadow).'px '.esc_attr($tech_software_company_wooproducts_box_shadow).'px '.esc_attr($tech_software_company_wooproducts_box_shadow).'px #e4e4e4;';
	$tech_software_company_custom_css .='}';

	/*-------------- Footer Text -------------------*/

	$tech_software_company_footer_heading = get_theme_mod( 'tech_software_company_footer_heading','Left');
    if($tech_software_company_footer_heading == 'Left'){
		$tech_software_company_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
		$tech_software_company_custom_css .='text-align: left !important;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_footer_heading == 'Center'){
		$tech_software_company_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
			$tech_software_company_custom_css .='text-align: center !important;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_footer_heading == 'Right'){
		$tech_software_company_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
			$tech_software_company_custom_css .='text-align: right !important;';
		$tech_software_company_custom_css .='}';
	}

	$tech_software_company_footer_content = get_theme_mod( 'tech_software_company_footer_content','Left');
    if($tech_software_company_footer_content == 'Left'){
		$tech_software_company_custom_css .='#footer .widget{';
		$tech_software_company_custom_css .='text-align: left;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_footer_content == 'Center'){
		$tech_software_company_custom_css .='#footer .widget{';
			$tech_software_company_custom_css .='text-align: center;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_footer_content == 'Right'){
		$tech_software_company_custom_css .='#footer .widget{';
			$tech_software_company_custom_css .='text-align: right;';
		$tech_software_company_custom_css .='}';
	}

	// Footer Heading Font Size
	$tech_software_company_footer_font_size = get_theme_mod('tech_software_company_footer_font_size',24);
	$tech_software_company_custom_css .='#footer h3{';
		$tech_software_company_custom_css .='font-size: '.esc_attr($tech_software_company_footer_font_size).'px;';
	$tech_software_company_custom_css .='}';

	// Footer Heading Text Transform
	$tech_software_company_theme_lay = get_theme_mod( 'tech_software_company_footer_text_tranform','Capitalize');
    if($tech_software_company_theme_lay == 'Uppercase'){
		$tech_software_company_custom_css .='#footer h3{';
			$tech_software_company_custom_css .='text-transform: uppercase;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_theme_lay == 'Lowercase'){
		$tech_software_company_custom_css .='#footer h3{';
			$tech_software_company_custom_css .='text-transform: lowercase;';
		$tech_software_company_custom_css .='}';
	}
	else if($tech_software_company_theme_lay == 'Capitalize'){
		$tech_software_company_custom_css .='#footer h3{';
			$tech_software_company_custom_css .='text-transform: capitalize;';
		$tech_software_company_custom_css .='}';
	}

	$tech_software_company_copyright_content_align = get_theme_mod('tech_software_company_copyright_content_align');
	if($tech_software_company_copyright_content_align != false){
		$tech_software_company_custom_css .='.copyright{';
			$tech_software_company_custom_css .='text-align: '.esc_attr($tech_software_company_copyright_content_align).'!important;';
		$tech_software_company_custom_css .='}';
		$tech_software_company_custom_css .='
		@media screen and (max-width:575px) {
			.copyright{';
			$tech_software_company_custom_css .='text-align: center !important;} }';
	}

	$tech_software_company_footer_content_font_size = get_theme_mod('tech_software_company_footer_content_font_size', 16);
	$tech_software_company_custom_css .='.copyright p{';
		$tech_software_company_custom_css .='font-size: '.esc_attr($tech_software_company_footer_content_font_size).'px;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_copyright_padding = get_theme_mod('tech_software_company_copyright_padding', 15);
	$tech_software_company_custom_css .='.copyright{';
		$tech_software_company_custom_css .='padding-top: '.esc_attr($tech_software_company_copyright_padding).'px; padding-bottom: '.esc_attr($tech_software_company_copyright_padding).'px;';
	$tech_software_company_custom_css .='}';

	/*------ copyright text color -------*/
	$tech_software_company_footer_text_color = get_theme_mod('tech_software_company_footer_text_color');
	if($tech_software_company_footer_text_color != false){
		$tech_software_company_custom_css .='.copyright p, .copyright p a{';
			$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_footer_text_color).'!important;';
		$tech_software_company_custom_css .='}';
	}

	/*------ copyright background css -------*/
	$tech_software_company_footer_text_bg_color = get_theme_mod('tech_software_company_footer_text_bg_color');
	if($tech_software_company_footer_text_bg_color != false){
		$tech_software_company_custom_css .='.copyright{';
			$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_footer_text_bg_color).';';
		$tech_software_company_custom_css .='}';
	}

	$tech_software_company_footer_widget_bg_color = get_theme_mod('tech_software_company_footer_widget_bg_color');
	$tech_software_company_custom_css .='#footer{';
		$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_footer_widget_bg_color).';';
	$tech_software_company_custom_css .='}';

	$tech_software_company_footer_widget_bg_image = get_theme_mod('tech_software_company_footer_widget_bg_image');
	if($tech_software_company_footer_widget_bg_image != false){
		$tech_software_company_custom_css .='#footer{';
			$tech_software_company_custom_css .='background: url('.esc_attr($tech_software_company_footer_widget_bg_image).'); background-size: cover;';
		$tech_software_company_custom_css .='}';
	}

	// scroll to top bg color
	$tech_software_company_back_to_top_bg_color = get_theme_mod('tech_software_company_back_to_top_bg_color');
	$tech_software_company_custom_css .='#scroll-top{';
		$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_back_to_top_bg_color).';';
		$tech_software_company_custom_css .='border-color: '.esc_attr($tech_software_company_back_to_top_bg_color).';';
	$tech_software_company_custom_css .='}';

	// scroll to top bg hover color
	$tech_software_company_back_to_top_bg_hover_color = get_theme_mod('tech_software_company_back_to_top_bg_hover_color');
	$tech_software_company_custom_css .='#scroll-top:hover{';
		$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_back_to_top_bg_hover_color).';';
		$tech_software_company_custom_css .='border-color: '.esc_attr($tech_software_company_back_to_top_bg_hover_color).';';
	$tech_software_company_custom_css .='}';

	// scroll to top
	$tech_software_company_scroll_font_size_icon = get_theme_mod('tech_software_company_scroll_font_size_icon', 22);
	$tech_software_company_custom_css .='#scroll-top i{';
		$tech_software_company_custom_css .='font-size: '.esc_attr($tech_software_company_scroll_font_size_icon).'px;';
	$tech_software_company_custom_css .='}';

	// Slider Height 
	$tech_software_company_slider_image_height = get_theme_mod('tech_software_company_slider_image_height');
	$tech_software_company_custom_css .='#slider img{';
		$tech_software_company_custom_css .='height: '.esc_attr($tech_software_company_slider_image_height).'px;';
	$tech_software_company_custom_css .='}';

	// button font size
	$tech_software_company_button_font_size = get_theme_mod('tech_software_company_button_font_size');
	$tech_software_company_custom_css .='.page-box .new-text .read-more-btn a{';
		$tech_software_company_custom_css .='font-size: '.esc_attr($tech_software_company_button_font_size).'px;';
	$tech_software_company_custom_css .='}';

	// font weight
	$tech_software_company_btn_font_weight = get_theme_mod('tech_software_company_btn_font_weight');{
	$tech_software_company_custom_css .='.page-box .new-text .read-more-btn a{';
	$tech_software_company_custom_css .='font-weight: '.esc_attr($tech_software_company_btn_font_weight).';';
	$tech_software_company_custom_css .='}';
	}

	// Button Text Transform
	$tech_software_company_theme_lay = get_theme_mod( 'tech_software_company_button_text_transform','Uppercase');
    if($tech_software_company_theme_lay == 'Uppercase'){
		$tech_software_company_custom_css .='.page-box .new-text .read-more-btn a{';
			$tech_software_company_custom_css .='text-transform: uppercase;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_theme_lay == 'Lowercase'){
		$tech_software_company_custom_css .='.page-box .new-text .read-more-btn a{';
			$tech_software_company_custom_css .='text-transform: lowercase;';
		$tech_software_company_custom_css .='}';
	}
	else if($tech_software_company_theme_lay == 'Capitalize'){
		$tech_software_company_custom_css .='.page-box .new-text .read-more-btn a{';
			$tech_software_company_custom_css .='text-transform: capitalize;';
		$tech_software_company_custom_css .='}';
	}

	// Display Blog Post 
	$tech_software_company_display_blog_page_post = get_theme_mod( 'tech_software_company_display_blog_page_post','In Box');
    if($tech_software_company_display_blog_page_post == 'Without Box'){
		$tech_software_company_custom_css .='.page-box{';
			$tech_software_company_custom_css .='border:none; margin:25px 0;';
		$tech_software_company_custom_css .='}';
	}

	// Blog Post Alignment
	$tech_software_company_blog_post_alignment = get_theme_mod( 'tech_software_company_blog_post_alignment','Center');
    if($tech_software_company_blog_post_alignment == 'Left'){
		$tech_software_company_custom_css .='.our-services .page-box .new-text, .our-services .page-box .new-text p{';
		$tech_software_company_custom_css .='text-align: left !important;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_blog_post_alignment == 'Center'){
		$tech_software_company_custom_css .='.our-services .page-box .new-text, .our-services .page-box .new-text p{';
			$tech_software_company_custom_css .='text-align: center !important;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_blog_post_alignment == 'Right'){
		$tech_software_company_custom_css .='.our-services .page-box .new-text, .our-services .page-box .new-text p{';
			$tech_software_company_custom_css .='text-align: right !important;';
		$tech_software_company_custom_css .='}';
	}

	// Pagination Alignment
	$tech_software_company_pagination_alignment = get_theme_mod( 'tech_software_company_pagination_alignment','Left');
    if($tech_software_company_pagination_alignment == 'Left'){
		$tech_software_company_custom_css .='.pagination, .nav-links{';
		$tech_software_company_custom_css .='float: left;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_pagination_alignment == 'Center'){
		$tech_software_company_custom_css .='.pagination, .nav-links{';
			$tech_software_company_custom_css .='justify-content: center; float: none;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_pagination_alignment == 'Right'){
		$tech_software_company_custom_css .='.pagination, .nav-links{';
			$tech_software_company_custom_css .='float: right;';
		$tech_software_company_custom_css .='}';
	}

	//slider button bg color
	$tech_software_company_slider_btn_bg_color = get_theme_mod('tech_software_company_slider_btn_bg_color');
	$tech_software_company_custom_css .='#slider .carousel-caption .read-btn a{';
		$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_slider_btn_bg_color).';';
	$tech_software_company_custom_css .='}';

	// slider overlay
	$tech_software_company_slider_overlay = get_theme_mod('tech_software_company_slider_overlay', true);
	if($tech_software_company_slider_overlay == false){
		$tech_software_company_custom_css .='#slider img{';
			$tech_software_company_custom_css .='opacity:1;';
		$tech_software_company_custom_css .='}';
	} 
	$tech_software_company_slider_image_overlay_color = get_theme_mod('tech_software_company_slider_image_overlay_color', true);
	if($tech_software_company_slider_overlay != false){
		$tech_software_company_custom_css .='#slider{';
			$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_slider_image_overlay_color).';';
		$tech_software_company_custom_css .='}';
	}

	// site title and tagline font size option
	$tech_software_company_site_title_size_option = get_theme_mod('tech_software_company_site_title_size_option', 30);{
	$tech_software_company_custom_css .='.logo h1 a, .logo p a{';
	$tech_software_company_custom_css .='font-size: '.esc_attr($tech_software_company_site_title_size_option).'px;';
		$tech_software_company_custom_css .='}';
	}

	$tech_software_company_site_tagline_size_option = get_theme_mod('tech_software_company_site_tagline_size_option', 12);{
	$tech_software_company_custom_css .='.logo p{';
	$tech_software_company_custom_css .='font-size: '.esc_attr($tech_software_company_site_tagline_size_option).'px !important;';
		$tech_software_company_custom_css .='}';
	}

	// woocommerce product sale settings
	$tech_software_company_border_radius_product_sale = get_theme_mod('tech_software_company_border_radius_product_sale',0);
	$tech_software_company_custom_css .='.woocommerce span.onsale {';
		$tech_software_company_custom_css .='border-radius: '.esc_attr($tech_software_company_border_radius_product_sale).'px;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_align_product_sale = get_theme_mod('tech_software_company_align_product_sale', 'Right');
	if($tech_software_company_align_product_sale == 'Right' ){
		$tech_software_company_custom_css .='.woocommerce ul.products li.product .onsale{';
			$tech_software_company_custom_css .=' left:auto; right:0;';
		$tech_software_company_custom_css .='}';
	}elseif($tech_software_company_align_product_sale == 'Left' ){
		$tech_software_company_custom_css .='.woocommerce ul.products li.product .onsale{';
			$tech_software_company_custom_css .=' left:0; right:auto;';
		$tech_software_company_custom_css .='}';
	}

	$tech_software_company_product_sale_font_size = get_theme_mod('tech_software_company_product_sale_font_size',14);
	$tech_software_company_custom_css .='.woocommerce span.onsale{';
		$tech_software_company_custom_css .='font-size: '.esc_attr($tech_software_company_product_sale_font_size).'px;';
	$tech_software_company_custom_css .='}';

	// product sale padding top /bottom
	$tech_software_company_sale_padding_top = get_theme_mod('tech_software_company_sale_padding_top', '');
	$tech_software_company_custom_css .='.woocommerce ul.products li.product .onsale{';
	$tech_software_company_custom_css .='padding-top: '.esc_attr($tech_software_company_sale_padding_top).'px; padding-bottom: '.esc_attr($tech_software_company_sale_padding_top).'px !important;';
	$tech_software_company_custom_css .='}';

	// product sale padding left/right
	$tech_software_company_sale_padding_left = get_theme_mod('tech_software_company_sale_padding_left', '');
	$tech_software_company_custom_css .='.woocommerce ul.products li.product .onsale{';
	$tech_software_company_custom_css .='padding-left: '.esc_attr($tech_software_company_sale_padding_left).'px; padding-right: '.esc_attr($tech_software_company_sale_padding_left).'px;';
	$tech_software_company_custom_css .='}';

	// preloader background image
	$tech_software_company_preloader_bg_image = get_theme_mod('tech_software_company_preloader_bg_image');
	if($tech_software_company_preloader_bg_image != false){
		$tech_software_company_custom_css .='#loader-wrapper .loader-section, #loader-wrapper{';
			$tech_software_company_custom_css .='background: url('.esc_attr($tech_software_company_preloader_bg_image).'); background-size: cover;';
		$tech_software_company_custom_css .='}';
	}

	// preloader background option 
	$tech_software_company_loader_background_color_first = get_theme_mod('tech_software_company_loader_background_color_first');
	$tech_software_company_custom_css .='#loader-wrapper .loader-section, #loader-wrapper{';
		$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_loader_background_color_first).';';
	$tech_software_company_custom_css .='} ';

	// breadcrumb color
	$tech_software_company_breadcrumb_color = get_theme_mod('tech_software_company_breadcrumb_color');
	$tech_software_company_custom_css .='.bradcrumbs a, .bradcrumbs span{';
	$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_breadcrumb_color).';';
	$tech_software_company_custom_css .='} ';

	// breadcrumb bg color
	$tech_software_company_breadcrumb_bg_color = get_theme_mod('tech_software_company_breadcrumb_bg_color');
	$tech_software_company_custom_css .='.bradcrumbs a, .bradcrumbs span{';
	$tech_software_company_custom_css .='background-color: '.esc_attr($tech_software_company_breadcrumb_bg_color).';';
	$tech_software_company_custom_css .='} ';

	// woocommerce Product Navigation
	$tech_software_company_products_navigation = get_theme_mod('tech_software_company_products_navigation', 'Yes');
	if($tech_software_company_products_navigation == 'No'){
		$tech_software_company_custom_css .='.woocommerce nav.woocommerce-pagination{';
			$tech_software_company_custom_css .='display: none;';
		$tech_software_company_custom_css .='}';
	}

	// featured image setting
	$tech_software_company_featured_img_border_radius = get_theme_mod('tech_software_company_featured_img_border_radius', 0);
	$tech_software_company_custom_css .='.our-services img{';
		$tech_software_company_custom_css .='border-radius: '.esc_attr($tech_software_company_featured_img_border_radius).'px;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_featured_img_box_shadow = get_theme_mod('tech_software_company_featured_img_box_shadow',0);
	$tech_software_company_custom_css .='.our-services img{';
		$tech_software_company_custom_css .='box-shadow: '.esc_attr($tech_software_company_featured_img_box_shadow).'px '.esc_attr($tech_software_company_featured_img_box_shadow).'px '.esc_attr($tech_software_company_featured_img_box_shadow).'px #ccc;';
	$tech_software_company_custom_css .='}';

	//First Cap (Blog Post)
	$tech_software_company_show_first_caps = get_theme_mod('tech_software_company_show_first_caps', 'false');
	if($tech_software_company_show_first_caps == 'true' ){
	$tech_software_company_custom_css .='.page-box .entry-content p:nth-of-type(1)::first-letter{';
	$tech_software_company_custom_css .=' font-size: 55px; font-weight: 600;';
	$tech_software_company_custom_css .=' margin-right: 6px;';
	$tech_software_company_custom_css .=' line-height: 1;';
	$tech_software_company_custom_css .='}';
	}elseif($tech_software_company_show_first_caps == 'false' ){
	$tech_software_company_custom_css .='.page-box .entry-content p:nth-of-type(1)::first-letter {';
	$tech_software_company_custom_css .='display: none;';
	$tech_software_company_custom_css .='}';
	}

	//First Cap (Single Post)
	$tech_software_company_single_post_first_caps = get_theme_mod('tech_software_company_single_post_first_caps', 'false');
	if($tech_software_company_single_post_first_caps == 'true' ){
	$tech_software_company_custom_css .='.page-box-single .new-text .entry-content p:nth-of-type(1)::first-letter{';
	$tech_software_company_custom_css .=' font-size: 55px; font-weight: 600;';
	$tech_software_company_custom_css .=' margin-right: 6px;';
	$tech_software_company_custom_css .=' line-height: 1;';
	$tech_software_company_custom_css .='}';
	}elseif($tech_software_company_single_post_first_caps == 'false' ){
	$tech_software_company_custom_css .='.page-box-single .new-text .entry-content p:nth-of-type(1)::first-letter {';
	$tech_software_company_custom_css .='display: none;';
	$tech_software_company_custom_css .='}';
	}

	// slider top and bottom padding
	$tech_software_company_top_bottom_slider_content_space = get_theme_mod('tech_software_company_top_bottom_slider_content_space');
	$tech_software_company_left_right_slider_content_space = get_theme_mod('tech_software_company_left_right_slider_content_space');
	$tech_software_company_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1, #slider .inner_carousel p, #slider .know-btn{';
		$tech_software_company_custom_css .='top: '.esc_attr($tech_software_company_top_bottom_slider_content_space).'%; bottom: '.esc_attr($tech_software_company_top_bottom_slider_content_space).'%;left: '.esc_attr($tech_software_company_left_right_slider_content_space).'%;right: '.esc_attr($tech_software_company_left_right_slider_content_space).'%;';
	$tech_software_company_custom_css .='}';

	// Topbar padding top bottom
	$tech_software_company_topbar_top_bottom_spacing = get_theme_mod('tech_software_company_topbar_top_bottom_spacing');
	$tech_software_company_custom_css .='.top-header{';
		$tech_software_company_custom_css .='padding-top: '.esc_attr($tech_software_company_topbar_top_bottom_spacing).'px !important; padding-bottom: '.esc_attr($tech_software_company_topbar_top_bottom_spacing).'px !important;';
	$tech_software_company_custom_css .='}';

	// resposive settings
	$tech_software_company_slider = get_theme_mod( 'tech_software_company_responsive_slider',true);
	if($tech_software_company_slider == true && get_theme_mod( 'tech_software_company_slider_hide', true) == false){
    	$tech_software_company_custom_css .='#slider{';
			$tech_software_company_custom_css .='display:none;';
		$tech_software_company_custom_css .='} ';
	}
    if($tech_software_company_slider == true){
    	$tech_software_company_custom_css .='@media screen and (max-width:575px) {';
		$tech_software_company_custom_css .='#slider{';
			$tech_software_company_custom_css .='display:block;';
		$tech_software_company_custom_css .='} }';
	}else if($tech_software_company_slider == false){
		$tech_software_company_custom_css .='@media screen and (max-width:575px) {';
		$tech_software_company_custom_css .='#slider{';
			$tech_software_company_custom_css .='display:none;';
		$tech_software_company_custom_css .='} }';
	}

	// scroll to top
	$tech_software_company_scroll = get_theme_mod( 'tech_software_company_responsive_scroll',true);
	if($tech_software_company_scroll == true && get_theme_mod( 'tech_software_company_enable_disable_scroll', true) == false){
    	$tech_software_company_custom_css .='#scroll-top{';
			$tech_software_company_custom_css .='visibility: hidden;';
		$tech_software_company_custom_css .='} ';
	}
    if($tech_software_company_scroll == true){
    	$tech_software_company_custom_css .='@media screen and (max-width:575px) {';
		$tech_software_company_custom_css .='#scroll-top{';
			$tech_software_company_custom_css .='visibility: visible;';
		$tech_software_company_custom_css .='} }';
	}else if($tech_software_company_scroll == false){
		$tech_software_company_custom_css .='@media screen and (max-width:575px) {';
		$tech_software_company_custom_css .='#scroll-top{';
			$tech_software_company_custom_css .='visibility: hidden;';
		$tech_software_company_custom_css .='} }';
	}

// preloader
	$tech_software_company_loader = get_theme_mod( 'tech_software_company_responsive_preloader', true);
	if($tech_software_company_loader == true && get_theme_mod( 'tech_software_company_preloader_option', true) == false){
    	$tech_software_company_custom_css .='#loader-wrapper{';
			$tech_software_company_custom_css .='display:none;';
		$tech_software_company_custom_css .='} ';
	}
    if($tech_software_company_loader == true){
    	$tech_software_company_custom_css .='@media screen and (max-width:575px) {';
		$tech_software_company_custom_css .='#loader-wrapper{';
			$tech_software_company_custom_css .='display:block;';
		$tech_software_company_custom_css .='} }';
	}else if($tech_software_company_loader == false){
		$tech_software_company_custom_css .='@media screen and (max-width:575px) {';
		$tech_software_company_custom_css .='#loader-wrapper{';
			$tech_software_company_custom_css .='display:none;';
		$tech_software_company_custom_css .='} }';
	}

	// Menu Text Transform
	$tech_software_company_theme_lay = get_theme_mod( 'tech_software_company_text_tranform_menu','Uppercase');
    if($tech_software_company_theme_lay == 'Uppercase'){
		$tech_software_company_custom_css .='.primary-navigation a{';
			$tech_software_company_custom_css .='text-transform: uppercase;';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_theme_lay == 'Lowercase'){
		$tech_software_company_custom_css .='.primary-navigation a{';
			$tech_software_company_custom_css .='text-transform: lowercase;';
		$tech_software_company_custom_css .='}';
	}
	else if($tech_software_company_theme_lay == 'Capitalize'){
		$tech_software_company_custom_css .='.primary-navigation a{';
			$tech_software_company_custom_css .='text-transform: capitalize;';
		$tech_software_company_custom_css .='}';
	}

	// menu font size
	$tech_software_company_menus_font_size = get_theme_mod('tech_software_company_menus_font_size',12);
	$tech_software_company_custom_css .='.primary-navigation a, .primary-navigation ul ul a, .sf-arrows .sf-with-ul:after, #menu-sidebar .primary-navigation a{';
		$tech_software_company_custom_css .='font-size: '.esc_attr($tech_software_company_menus_font_size).'px;';
	$tech_software_company_custom_css .='}';

	// menu font weight
	$tech_software_company_menu_weight = get_theme_mod('tech_software_company_menu_weight');{
		$tech_software_company_custom_css .='.primary-navigation a, .primary-navigation ul ul a, .sf-arrows .sf-with-ul:after, #menu-sidebar .primary-navigation a{';
			$tech_software_company_custom_css .='font-weight: '.esc_attr($tech_software_company_menu_weight).';';
		$tech_software_company_custom_css .='}';
	}

	// menu padding
	$tech_software_company_menus_padding = get_theme_mod('tech_software_company_menus_padding');
	$tech_software_company_custom_css .='.primary-navigation ul li{';
		$tech_software_company_custom_css .='padding: '.esc_attr($tech_software_company_menus_padding).'px;';
	$tech_software_company_custom_css .='}';

	// Menu hover effect
	$tech_software_company_menus_item = get_theme_mod( 'tech_software_company_menus_item_style','None');
    if($tech_software_company_menus_item == 'None'){
		$tech_software_company_custom_css .='.primary-navigation ul a{';
			$tech_software_company_custom_css .='';
		$tech_software_company_custom_css .='}';
	}else if($tech_software_company_menus_item == 'Zoom In'){
		$tech_software_company_custom_css .='.primary-navigation ul a:hover{';
			$tech_software_company_custom_css .='transition: all 0.3s ease-in-out !important; transform: scale(1.2) !important;';
		$tech_software_company_custom_css .='}';
	}

	// Menu Color Option
	$tech_software_company_menu_color_settings = get_theme_mod('tech_software_company_menu_color_settings');
	$tech_software_company_custom_css .='.primary-navigation ul li a{';
		$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_menu_color_settings).';';
	$tech_software_company_custom_css .='} ';

	// Menu Hover Color Option
	$tech_software_company_menu_hover_color_settings = get_theme_mod('tech_software_company_menu_hover_color_settings');
	$tech_software_company_custom_css .='.primary-navigation ul li a:hover {';
		$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_menu_hover_color_settings).';';
	$tech_software_company_custom_css .='} ';

	// Submenu Color Option
	$tech_software_company_submenu_color_settings = get_theme_mod('tech_software_company_submenu_color_settings');
	$tech_software_company_custom_css .='.primary-navigation ul.sub-menu li a, .primary-navigation ul.children li a{';
		$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_submenu_color_settings).';';
	$tech_software_company_custom_css .='} ';

	// Submenu Hover Color Option
	$tech_software_company_submenu_hover_color_settings = get_theme_mod('tech_software_company_submenu_hover_color_settings');
	$tech_software_company_custom_css .='.primary-navigation ul.sub-menu li a:hover, .primary-navigation ul.children li a:hover{';
	$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_submenu_hover_color_settings).';';
	$tech_software_company_custom_css .='} ';

	// site tagline color
	$tech_software_company_site_tagline_color = get_theme_mod('tech_software_company_site_tagline_color');
	$tech_software_company_custom_css .='.logo p {';
		$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_site_tagline_color).' !important;';
	$tech_software_company_custom_css .='}';

	// site title color
	$tech_software_company_site_title_color = get_theme_mod('tech_software_company_site_title_color');
	$tech_software_company_custom_css .='.site-title a{';
		$tech_software_company_custom_css .='color: '.esc_attr($tech_software_company_site_title_color).' !important;';
	$tech_software_company_custom_css .='}';

	// site top-bottom logo padding 
	$tech_software_company_logo_padding_top = get_theme_mod('tech_software_company_logo_padding_top', '');
	$tech_software_company_custom_css .='.logo{';
	$tech_software_company_custom_css .='padding-top: '.esc_attr($tech_software_company_logo_padding_top).'px; padding-bottom: '.esc_attr($tech_software_company_logo_padding_top).'px;';
	$tech_software_company_custom_css .='}';

	// site left-right logo padding 
	$tech_software_company_logo_padding_left = get_theme_mod('tech_software_company_logo_padding_left', '');
	$tech_software_company_custom_css .='.logo{';
	$tech_software_company_custom_css .='padding-left: '.esc_attr($tech_software_company_logo_padding_left).'px; padding-right: '.esc_attr($tech_software_company_logo_padding_left).'px;';
	$tech_software_company_custom_css .='}';

	// site top-bottom logo margin 
	$tech_software_company_logo_margin_top = get_theme_mod('tech_software_company_logo_margin_top', '');
	$tech_software_company_custom_css .='.logo{';
	$tech_software_company_custom_css .='margin-top: '.esc_attr($tech_software_company_logo_margin_top).'px; margin-bottom: '.esc_attr($tech_software_company_logo_margin_top).'px;';
	$tech_software_company_custom_css .='}';

	// site left-right logo margin
	$tech_software_company_logo_margin_left = get_theme_mod('tech_software_company_logo_margin_left', '');
	$tech_software_company_custom_css .='.logo{';
	$tech_software_company_custom_css .='margin-left: '.esc_attr($tech_software_company_logo_margin_left).'px; margin-right: '.esc_attr($tech_software_company_logo_margin_left).'px;';
	$tech_software_company_custom_css .='}';

	// toggle button color 
	$tech_software_company_taggle_menu_bg_color_settings = get_theme_mod('tech_software_company_taggle_menu_bg_color_settings', '');
	$tech_software_company_custom_css .='.toggle-menu i {';
	$tech_software_company_custom_css .='background-color:'.esc_attr($tech_software_company_taggle_menu_bg_color_settings).'';
	$tech_software_company_custom_css .='}';

	// single post image setting
	$tech_software_company_single_img_border_radius = get_theme_mod('tech_software_company_single_img_border_radius', 0);
	$tech_software_company_custom_css .='.page-box-single .box-img img{';
		$tech_software_company_custom_css .='border-radius: '.esc_attr($tech_software_company_single_img_border_radius).'px;';
	$tech_software_company_custom_css .='}';

	$tech_software_company_single_img_box_shadow = get_theme_mod('tech_software_company_single_img_box_shadow',0);
	$tech_software_company_custom_css .='.page-box-single .box-img img{';
		$tech_software_company_custom_css .='box-shadow: '.esc_attr($tech_software_company_single_img_box_shadow).'px '.esc_attr($tech_software_company_single_img_box_shadow).'px '.esc_attr($tech_software_company_single_img_box_shadow).'px #ccc;';
	$tech_software_company_custom_css .='}';

	/*----Comment title text----*/
	$tech_software_company_title_comment_form = get_theme_mod('
		tech_software_company_title_comment_form', 'Leave a Reply');
	if($tech_software_company_title_comment_form == ''){
	$tech_software_company_custom_css .='#comments h2#reply-title {';
	$tech_software_company_custom_css .='display: none;';
	$tech_software_company_custom_css .='}';
	}

	/*----Comment button text----*/
	$tech_software_company_comment_form_button_content = get_theme_mod('tech_software_company_comment_form_button_content', 'Post Comment');
	if($tech_software_company_comment_form_button_content == ''){
	$tech_software_company_custom_css .='#comments p.form-submit {';
	$tech_software_company_custom_css .='display: none;';
	$tech_software_company_custom_css .='}';
	}

	/*---- Comment form ----*/
	$tech_software_company_comment_width = get_theme_mod('tech_software_company_comment_width', '100');
	$tech_software_company_custom_css .='#comments textarea{';
	$tech_software_company_custom_css .=' width:'.esc_attr($tech_software_company_comment_width).'%;';
	$tech_software_company_custom_css .='}';
