=== Tech Software Company WordPress Theme ===
Contributors: Themeshopy
Tags: wide-blocks, flexible-header, block-styles, block-patterns, left-sidebar, right-sidebar, one-column, two-columns, three-columns, four-columns, grid-layout, custom-colors, custom-background, custom-logo, custom-menu, custom-header, editor-style, featured-images, footer-widgets, full-width-template, theme-options, translation-ready, threaded-comments, blog, e-commerce, portfolio
Requires at least: 5.0
Tested up to: 6.7
Requires PHP: 7.2
Stable tag: 0.6.5
License: GPLv3.0 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Tech Software Company is a robust WordPress theme with a minimalist approach and sophisticated design. IT companies, tech startups, Digital Marketers, SEO Agencies, Tch Support Companies, IT business endeavors, SaaS, Startups, IT Consulting, Cybersecurity, Fintech, AI Solutions, Cloud Computing, Data Analytics, Software Development, Digital Marketing, E-commerce, Blockchain, Web Design, Mobile Apps, Tech Support and relevant companies will find the design absolutely stunning and useful.

== Description ==

Tech Software Company is a robust WordPress theme with a minimalist approach and sophisticated design. IT companies, tech startups, Digital Marketers, SEO Agencies, Tch Support Companies, IT business endeavors, SaaS, Startups, IT Consulting, Cybersecurity, Fintech, AI Solutions, Cloud Computing, Data Analytics, Software Development, Digital Marketing, E-commerce, Blockchain, Web Design, Mobile Apps, Tech Support and relevant companies will find the design absolutely stunning and useful. Digital, as well as marketing agencies, can also use this design to get online. There is a retina-ready layout giving a sophisticated display of content and imagery and a responsive design makes it simple and adaptable to make your website scale perfectly to any screen size. It reflects, style, elegance, and modern design without compromising the quality as the codes included in the design are well optimized. These secure and clean codes also take of the needs of the SEO of your website. There are a lot of customization options for you to tweak and choices available for colors and typography. Interactive websites are loved by the audience and that is why you will find plenty of CTAs placed at proper locations to boost your conversion as well. With enough shortcodes and custom widgets, you will spot the social media icons in the design. This flexible theme has a beautiful banner and full-width slider with slider settings. There are various sections such as Testimonials, Team, and user-friendly customization options to make the changes easily.

== Changelog ==

= 0.1 =
* Initial version Released.

= 0.1.1 =
* Added post time settings.
* Added language folder.

= 0.1.2 =
* Added show/hide Woocommerce Products Navigation settings.
* Added footer link.
* Added get started.
* Updated POT file.

= 0.1.3 =
* Added show/hide Blog post image option.
* Added blog post border radius option.
* Updated POT file.

= 0.1.4 =
* Added blog post box shadow option.
* Updated POT file.

= 0.1.5 =
* Added top bottom slider content spacing settings.
* Updated POT file.

= 0.1.6 =
* Added left right slider content spacing settings.
* Updated POT file.

= 0.1.7 =
* Added topbar top bottom spacing option.
* Updated POT file.

= 0.1.8 =
* Added show/hide search option.
* Updated POT file.

= 0.1.9 =
* Added slider responsive setting for mobile.
* Updated POT file.

= 0.2 =
* Added scroll to top responsive setting for mobile.
* Updated POT file.

= 0.2.1 =
* Added condition for slider image in custom-front-page.php file.
* Added preloader responsive setting for mobile.
* Updated POT file.

= 0.2.2 =
* Added block pattern in theme.

= 0.2.3 =
* Added menu color option.
* Added menu hover color option.
* Added sub-menu color option.
* Updated .pot file.

= 0.2.4 =
* Added logo padding option.
* Added logo margin option.
* Added site title font color option.
* Added site tagline font color option.
* Added toggle button bg color option.
* Added show/hide single post comment box option.
* Added sub-menu hover color option.
* Added product sale padding option.
* Added POT file.

= 0.2.5 =
* Added prefixing for variables for post formats.
* Added requires at least in style.css.
* Removed esc_url in function.php.
* Changed font family function.
* Added the webfont license
* Updated pot file.

= 0.2.6 =
* Resolved css for copyright text alignment.
* Resolved css for slider section contact form.
* Added shop page sidebar layout option.
* Added single product page sidebar layout option.
* Updated pot file.

= 0.2.7 =
* Added show/hide single post pagination option. 
* Updated pot file. 

= 0.2.8 =
* Added single post category option.
* Added comment form heading text option.
* Added comment form button text option.
* Added comment textarea width option.
* Updated .pot file.

= 0.2.9 =
* Added single post meta box seperator option.
* Updated .pot file.

= 0.3 =
* Added single post date, author, comment and time option.
* Updated pot. file.

= 0.3.1 =
* Added menu text transform, menu font size and menu weight options in menu settings.
* Added related post content limit option in single post settings.
* Updated .pot file.

= 0.3.2 =
* Change menu font weight text in menu settings.
* Added menus padding option in menu settings.
* Updated .pot file.

= 0.3.3 =
* Added button font size and text transform options in blog page settings.
* Added single product slider image option.
* Updated .pot file.

= 0.3.4 =
* Added single post image border radius option in single post settings.
* Added single post image shadow option in single post settings.
* Updated .pot file.

= 0.3.5 = 
* Added breadcrumbs in single page and single post page.
* Added show / hide single page breadcrumb option in layout settings.
* Added show / hide single post breadcrumb option in single post settings.
* Added breadcrumb color option in layout settings section.
* Added breadcrumb background color option in layout settings section.
* Added single product zoom in image option.
* Added show / hide footer option in footer text section. 
* Added show / hide copyright option in footer text section.
* Added related post settings section.
* Updated .pot file.

= 0.3.6 =  
* Added scroll back to top icon option in footer text section.
* Added show / hide slider button option in slider settings.
* Resolved error for font family.
* Updated .pot file.

= 0.3.7 =   
* Added second preloader in theme.
* Added preloader type option in layout settings.
* Added background color for preloader 2 option in layout settings.
* Added back to top background color option in footer text section.
* Added css for categories in single post.
* Updated .pot file.

= 0.3.8 =    
* Added back to top background hover color option in footer text section.
* Added theme color option in theme settings.
* Added first and second color option in theme color option.
* Resolved css error for go pro button in customizer.
* Updated .pot file.

= 0.3.9 =     
* Added woocommerce settings section in woocommerce.
* Rearranged layout settings.
* Renamed as blog page layouts in layout settings.
* Resolved error for single page layouts in layout settings.
* Added three and four column option for blog page layouts in layout settings.
* Added three-columns and four-columns tag.
* Tested upto WP v6.3
* Updated .pot file.

= 0.4 =     
* Resolved error for menus.
* Added pagination on clearing floats page.
* Resolved css error for block images.
* Resolved css error for block cover.
* Resolved css error for block gallery.
* Resolved css error for block button.
* Resolved error for time settings in blog page.
* Resolved error for meta box separator in blog page.
* Resolved css error for single post category.
* Added esc_attr in archive-product.php and single-product.php
* Rearranged woocommerce settings.
* Resolved css error for block widgets in sidebar.
* Resolved css error for search button in sidebar.
* Resolved css error for breadcrumbs in responsive media.
* Resolved css error for search button in no result page.

= 0.4.1 =      
* Resolved error for meta box separator in single post.
* Resolved css error in block layout.
* Resolved css error for my account page.
* Resolved error for text area in comments.
* Resolved error for recent comments in sidebar.

= 0.4.2 =      
* Added theme activation notice.
* Added post date icon, comments icon, time icon and author icon options in blog page settings.
* Added css for header image.
* Added css for block widgets sidebar.
* Added css for block widgets footer.
* Resolved css error for tag cloud in widgets block category.
* Resolved css error in blog page.
* Updated .pot file. 

= 0.4.3 =      
* Added post pagination option in blog post settings.
* Resolved error for breadcrumbs.
* Resolved error for tagline.
* Updated .pot file.

= 0.4.4 =      
* Added tgm.php and class-tgm-plugin-activation.php file.
* Added recommendation for ibtana in tgm.
* Added tgm license.
* Resolved sidebar issue in preview.
* Resolved get pro issue in cutomizer.
* Tested upto WP v6.4

= 0.4.5 =      
* Added css for cart and checkout page.
* Resolved heading issue in related post.
* Added classes in theme color option.
* Changed background color of preloader option in customizer.
* Added single post date icon, comments icon, time icon and author icon options in single post settings.
* Updated .pot file.

= 0.4.6 =      
* Added slider small text option in slider settings.
* Added button link option in slider settings. 
* Added slider button background color option in slider settings.
* Resolved error for social icons in topbar.
* Added facebook, twitter, linkedin and instagram icons option in social icons section.
* Updated .pot file. 

= 0.4.7 =      
* Added copyright text color option in footer text section.
* Added copyright background color option in footer text section.
* Updated .pot file. 
* Rearranged sections.

= 0.4.8 =      
* Added button font weight option in blog page settings.
* Added first cap (first capital letter) option in blog page settings.
* Updated .pot file. 
* Added recommendation for Contact Form 7 in tgm.
* Resolved css error for form on slider.

= 0.4.9 =      
* Rearranged button option settings.
* Added upgrade to pro button in slider settings.
* Updated .pot file. 

= 0.5 =      
* Resolved error in keyboard navigation for menu.
* Added footer widgets in preview.
* Added search and categories in sidebar for preview. 

= 0.5.1 =      
* Added search icon, mail icon, phone icon and location icon option in topbar section.
* Resolved error for slider button link.
* Resolved css error for textarea in single product page.
* Resolved underline issue.
* Resolved css error for search in footer.
* Resolved css error for sidebar in preview.
* Updated .pot file. 

= 0.5.2 =      
* Added footer heading alignment option in footer text section.
* Added footer content alignment option in footer text section.
* Updated .pot file. 
* Resolved css error for scroll icon font size in footer text section.
* Tested upto WP v6.5

= 0.5.3 =      
* Added preloader background image option in layout settings.
* Resolved css error for preloader.
* Resolved css error for footer widget background image in footer text section.
* Changed condition in copyright text alignment for responsive media.
* Resolved css error for menu colors option.
* Resolved css error for topbar.
* Updated .pot file. 

= 0.5.4 =      
* Update archive-product.php file.
* Update fontawesome-all.css file.
* Resolved escaping issue for premium features.

= 0.5.5 =      
* Added first cap (first capital letter) option in single post settings.
* Added open menu icon option in responsive settings. 
* Added close menu icon option in responsive settings.
* Updated .pot file. 

= 0.5.6 =      
* Added documentation button in customizer.
* Resolved error for shop page and single product page sidebar.
* Resolved css error for view cart.
* Resolved css error for block pattern.
* Resolved error for slider excerpt length in slider settings.

= 0.5.7 =      
* Added grid post settings section.
* Added show / hide post date, comment, author and time option in grid post settings.
* Updated .pot file.

= 0.5.8 =      
* Added preview button in customizer.
* Added footer heading font size option in footer text section. 
* Added footer heading text transform option in footer text section.
* Updated .pot file.
* Resolved css error for search in sidebar.

= 0.5.9 =      
* Added css for button in my account page.
* Added css for category in single product page.
* Resolved error for excerpt length in blog post settings.
* Tested upto WP v6.6

= 0.6 =      
* Added icon settings in grid post section.
* Updated .pot file.
* Updated rtl.css

= 0.6.1 =      
* Added excerpt length option in grid post settings.
* Added pagination alignment option in blog page settings.

= 0.6.2 =
* Added blog post alignment option in blog page settings.
* Added meta box separator option in grid post settings.
* Resolved css error for button in myaccount page.
* Added css for button in cart and checkout page.
* Updated .pot file.
* Resolved css for customizer.
* Tested upto WP v6.7

= 0.6.3 =
* Added menu hover effect option in menus settings.
* Updated form-checkout.php
* Resolved css error for pagination in single post.
* Added show/hide image option in related post settings.

= 0.6.4 =
* Added demo import.

= 0.6.5 =
* Added edit link in single posts.
* Added date in related posts.
* Resolved escaping issue.
* Updated .pot file.

== Resources ==

Tech Software Company WordPress Theme, Copyright 2021 Themeshopy
Tech Software Company is distributed under the terms of the GNU GPL

Tech Software Company WordPress Theme is derived from Twenty Sixteen WordPress Theme, Copyright 2014-2015 WordPress.org
Twenty Sixteen is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see .

Theme is Built using the following resource bundles.

1. Bootstrap 
	- Mark Otto
	- copyright 2011-2021, Mark Otto
	- https://github.com/twbs/bootstrap/releases/download/v5.0.0/bootstrap-5.0.0-dist.zip
	- License: Code released under the MIT License.
	- https://github.com/twbs/bootstrap/blob/main/LICENSE

2. Font-Awesome 
	- Dave Gandy
	- Copyright 2024 Fonticons, Dave Gandy
	- https://github.com/FortAwesome/Font-Awesome.git
	- License: Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License
	- https://github.com/FortAwesome/Font-Awesome/blob/6.x/LICENSE.txt

3. Customizer Pro 
	- Justin Tadlock
	- Copyright 2016, Justin Tadlock
	- https://github.com/justintadlock/trt-customizer-pro.git
	- License: GNU General Public License v2.0
	- http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

4. Superfish 
	- Joeldbirch
	- Copyright 2013, Justin Tadlock
	- https://github.com/joeldbirch/superfish.git
	- License: Free to use and abuse under the MIT license. v1.7.9
	- https://github.com/joeldbirch/superfish/blob/master/MIT-LICENSE.txt

5. SmoothScroll
	- Balazs Galambosi
	- Copyright 2010-2015, Balazs Galambosi
	- http://www.smoothscroll.net/
	- License: Licensed under the terms of the MIT license.
	- https://github.com/gblazex/smoothscroll-for-websites/blob/master/LICENSE

6. TGMPA 
    - GaryJones Copyright (C) 1989, 1991
    - https://github.com/TGMPA/TGM-Plugin-Activation/blob/develop/LICENSE.md
    - License: GNU General Public License v2.0

7. Webfonts Loader
	- https://github.com/WPTT/webfont-loader
	- License: https://github.com/WPTT/webfont-loader/blob/master/LICENSE

8. Screenshot Images
	License: CC0 1.0 Universal (CC0 1.0) 
	Source: https://pxhere.com/en/license

	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/photo/1562459

	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/photo/1562177

	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/photo/1555509

	License: CC0 1.0 Universal (CC0 1.0)
	Source: https://pxhere.com/en/photo/1557943